Title: How to <do-a-thing>

Goal
- Clear, outcome-oriented statement.

Prerequisites
- Tools, credentials, data, repo paths.

Steps
1) Step description with explicit nouns.
2) Include commands with flags and expected outputs.

Validation
- Assertions or checks (e.g., HTTP 200, file exists, test passes).

Rollback
- Steps to revert changes if something goes wrong.
